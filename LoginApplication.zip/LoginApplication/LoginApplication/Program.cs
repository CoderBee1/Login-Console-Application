﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            int j = 0;
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Login your account");
                Console.WriteLine("You have only 3 attempts to enter the account, otherwise you would be blocked..!");
                Console.WriteLine("Enter User Name: ");
                string userName = Console.ReadLine();
                Console.WriteLine("Enter Password: ");
                string pass = Console.ReadLine();

                if (userName != "musab" || pass != "musab123")
                    j++;
                    //Console.WriteLine("Login Failed");
                    //Console.ReadLine();
                else
                break;
            }

            if (j >2)
            {
                Console.WriteLine("Sorry, You are blocked");
            }
            else
                Console.WriteLine("Congratulations Login Successful");
                Console.ReadLine();
            //Console.WriteLine("Enter UserName: ");
            //string userName = Console.ReadLine();
            //Console.WriteLine("Enter Password: ");
            //string pass = Console.ReadLine();

            //if (userName != "ali" && pass != "123")
            //{
            //string userName = "ali";
            //string pass = "123";

            //}
            //else if (userName == "ali" && pass == "123")
            //{
            //    Console.WriteLine("Login Successful");
            //    Console.ReadLine();
            //}
            //else
            //{
            //    Console.WriteLine("you are blocked");
            //    Console.ReadLine();
            //}
        }
    }
}
